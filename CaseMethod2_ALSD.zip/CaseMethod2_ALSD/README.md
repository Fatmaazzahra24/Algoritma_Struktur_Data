# CaseMethod2_ALSD
iini adalah repository Case Method 2 praktikum ALSD milik Fatma Azzahra(05) dan Zaskia Maulidina(24)
