public class nodeKendaraan {
    kendaraan data;
    nodeKendaraan next;

    public nodeKendaraan(kendaraan data) {
        this.data = data;
        this.next = null;
    }
}
