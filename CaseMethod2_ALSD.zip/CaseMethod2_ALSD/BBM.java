public class BBM {
    String namaBBM;
    double hargaPerliter;
    int jumlahLiter;
    double totalBayar;

    public BBM(String namaBBM, double hargaPerliter, int jumlahLiter) {
        this.namaBBM = namaBBM;
        this.hargaPerliter = hargaPerliter;
        this.jumlahLiter = jumlahLiter;
    }
    
}